Upgrade truststore to 0.10.5
